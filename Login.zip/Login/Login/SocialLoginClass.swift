//
//  SocialLoginClass.swift
//  TheStage
//
//  Created by LN-MCMI-005 on 26/08/20.
//  Copyright © 2020 letsnurture. All rights reserved.
//

import Foundation
import UIKit
import FBSDKLoginKit
import GoogleSignIn
import SafariServices
import AuthenticationServices


var googleSignInConfig: GIDConfiguration?

extension UIViewController: SFSafariViewControllerDelegate {

    func configureGoogleSignIn() {
        googleSignInConfig = GIDConfiguration(clientID: GoogleLoginKey)
    }

    func loginWithGoogle() {
        guard let config = googleSignInConfig else {
            print("Google Sign-In configuration is missing")
            return
        }

        GIDSignIn.sharedInstance.signIn(with: config, presenting: self) { user, error in
            if let error = error {
                print("Google Sign-In failed: \(error.localizedDescription)")
                return
            }

            guard let user = user else {
                print("Google Sign-In user is nil")
                return
            }

            let authId = user.userID ?? ""
            let email = user.profile?.email ?? ""
            let fullName = user.profile?.name ?? ""
            let profileImageURL = user.profile?.imageURL(withDimension: 100)
            var picData = Data()

            if let url = profileImageURL {
                do {
                    picData = try Data(contentsOf: url)
                } catch {
                    print("Failed to load profile image: \(error.localizedDescription)")
                }
            }

            let img = UIImage(data: picData)
            let param = [
                "social_provider_id": authId,
                "first_name": fullName,
                "last_name": "",
                "social_provider": "google",
                "device_type": "1",
                "device_token": getDeviceToken(),
                "email": email,
                "mobile_os": "ios",
                "mobile_token": getDeviceToken()
            ]
            // Call your web service with the above parameters and image
            // self.WS_SocialLogin(url: URLS.SocialLogin.rawValue, param: param, image: img)
        }
    }


    // Facebook login and logout functions remain unchanged
    func loginWithFacebook() {
        let loginManager = LoginManager()
        loginManager.logIn(permissions: ["user_friends", "public_profile", "email"], from: self) { (result, error) in
            if let error = error {
                print("Failed to login: \(error.localizedDescription)")
                return
            }

            if AccessToken.current != nil {
                let params = ["fields": "id, name, first_name, last_name, picture.type(large), email"]

                GraphRequest(graphPath: "me", parameters: params).start { connection, fbResult, error in
                    if error == nil, let responseDictionary = fbResult as? NSDictionary {
                        print(responseDictionary)
                        let fbid = responseDictionary["id"] as! String
                        var emailID = ""
                        if let eID = responseDictionary["email"] {
                            emailID = eID as! String

                            if let picURL = responseDictionary["picture"] as? [String: AnyObject],
                               let picData = (picURL["data"] as? [String: AnyObject])?["url"] as? String,
                               let picURL = URL(string: picData),
                               let picData = try? Data(contentsOf: picURL) {
                                let img = UIImage(data: picData)
                                let param = [
                                    "social_provider_id": fbid,
                                    "first_name": "\(responseDictionary["first_name"] as! String) \(responseDictionary["last_name"] as! String)",
                                    "last_name": "",
                                    "social_provider": "facebook",
                                    "device_type": "1",
                                    "device_token": getDeviceToken(),
                                    "email": emailID,
                                    "mobile_os": "ios",
                                    "mobile_token": getDeviceToken()
                                ]
                                // Call your web service with the above parameters and image
                                // self.WS_SocialLogin(url: URLS.SocialLogin.rawValue, param: param, image: img)
                            }
                        } else {
                            // Show toast message: email not found
                        }
                    }
                }
            }
        }
    }

    func logoutFromFacebook() {
        let loginManager = LoginManager()
        loginManager.logOut()
        let cookies = HTTPCookieStorage.shared
        let facebookCookies = cookies.cookies(for: URL(string: "https://facebook.com/")!)
        for cookie in facebookCookies ?? [] {
            cookies.deleteCookie(cookie)
        }
    }
}

class LoginWithApple: NSObject, ASAuthorizationControllerDelegate, ASAuthorizationControllerPresentationContextProviding {

    var completionHandlerAppleSigninData: ((ASAuthorizationAppleIDCredential?) -> ())?

    static let shared = LoginWithApple()

    func loginWithApple(completionHandler: @escaping (ASAuthorizationAppleIDCredential?) -> ()) {
        self.completionHandlerAppleSigninData = completionHandler
        let appleIDProvider = ASAuthorizationAppleIDProvider()
        let request = appleIDProvider.createRequest()
        request.requestedScopes = [.fullName, .email]
        let authorizationController = ASAuthorizationController(authorizationRequests: [request])
        authorizationController.delegate = self
        authorizationController.presentationContextProvider = self
        authorizationController.performRequests()
    }

    func presentationAnchor(for controller: ASAuthorizationController) -> ASPresentationAnchor {
        return (UIApplication.shared.delegate?.window??.rootViewController?.view.window)!
    }

    func authorizationController(controller: ASAuthorizationController, didCompleteWithAuthorization authorization: ASAuthorization) {
        if let appleIDCredential = authorization.credential as? ASAuthorizationAppleIDCredential {
            KeychainItem.currentUserIdentifier = appleIDCredential.user
            KeychainItem.currentUserFirstName = appleIDCredential.fullName?.givenName
            KeychainItem.currentUserLastName = appleIDCredential.fullName?.familyName
            KeychainItem.currentUserEmail = appleIDCredential.email
            guard let idTokenString = String(data: appleIDCredential.identityToken ?? Data(), encoding: .utf8) else { return }
            KeychainItem.identityToken = idTokenString
            guard let codeString = String(data: appleIDCredential.authorizationCode ?? Data(), encoding: .utf8) else { return }
            KeychainItem.authCode = codeString
            completionHandlerAppleSigninData?(appleIDCredential)
        }
    }

    func authorizationController(controller: ASAuthorizationController, didCompleteWithError error: Error) {
        print(error.localizedDescription)
    }
}

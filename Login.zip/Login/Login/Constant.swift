//
//  Constant.swift
//  Login
//
//  Created by syed fazal abbas on 13/06/24.
//

import Foundation
import UIKit

let facebookKey = "986458001880684"//Live : "986458001880684"//Test : 324471399484596
let GoogleLoginKey = "521566189222-2hqh0oqrjlcmlpiq1m766kndj9t4drp3.apps.googleusercontent.com"
let appDelegate = UIApplication.shared.delegate as! AppDelegate
func setDeviceToken(_ token : String) {
    let defaults: UserDefaults = UserDefaults.standard
    do{
        let data: Data = try NSKeyedArchiver.archivedData(withRootObject: token, requiringSecureCoding: false)
        defaults.set(data, forKey: "deviceToken")
    }
    catch{
        
    }
    defaults.synchronize()
}
func removeDeviceToken() {
    let defaults: UserDefaults = UserDefaults.standard
    defaults.removeObject(forKey: "deviceToken")
    defaults.synchronize()
}
func getDeviceToken() -> String {
    let defaults: UserDefaults = UserDefaults.standard
    let data = defaults.object(forKey: "deviceToken") as? Data
    if data != nil {
        do {
            if let str = try! NSKeyedUnarchiver.unarchiveTopLevelObjectWithData(data!) as? String{
                return str
            }
            else {
                return "123456"
            }
        }
    }
    return "123456"
}

//
//  ViewController.swift
//  Login
//
//  Created by syed fazal abbas on 13/06/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func btnFb(_ sender: UIButton) {
        loginWithFacebook()
    }
    
    @IBAction func btnGoogle(_ sender: UIButton) {
//        loginWithGoogle()
    }
    
    @IBAction func btnApple(_ sender: UIButton) {
        if KeychainItem.currentUserIdentifier != nil {
            if KeychainItem.currentUserEmail != nil , KeychainItem.currentUserEmail != "" {
                let param = ["social_provider_id" : KeychainItem.currentUserIdentifier ?? "",
                             "first_name" : "\(KeychainItem.currentUserFirstName ?? "") \(KeychainItem.currentUserLastName ?? "")",
                             "last_name": "",
                             "social_provider" : "apple",
                             "device_type":"1",
                             "device_token":getDeviceToken(),
                             "profile_image" : "",
                             "password": "",
                             "email":KeychainItem.currentUserEmail ?? "",
                             "mobile_os" : "ios",
                             "mobile_token" : getDeviceToken()]
//                self.WS_SocialLogin(url: URLS.SocialLogin.rawValue, param: param, image: nil)
            }else {
                //show alert
//                UIAlertController.actionWith(Bundle.main.getAppName(), andMessage: popUpMessage.emailNotFound.rawValue, getStyle: .alert, controller: self, buttons: ["Ok"]) { (_) in }
            }
        } else {
            LoginWithApple.shared.loginWithApple { (credentials) in
                if credentials != nil{
                    if credentials?.email != "" , credentials?.email != nil {
                        let param = ["social_provider_id" : credentials?.user ?? "",
                                     "first_name" : "\(credentials?.fullName?.givenName ?? "") \(credentials?.fullName?.familyName ?? "")",
                                     "last_name": "",
                                     "social_provider" : "apple",
                                     "device_type":"1",
                                     "device_token":getDeviceToken(),
                                     "profile_image" : "",
                                     "password": "",
                                     "email":credentials?.email ?? "",
                                     "mobile_os" : "ios",
                                     "mobile_token" : getDeviceToken()]
//                        self.WS_SocialLogin(url: URLS.SocialLogin.rawValue, param: param, image: nil)
                    }
                }else {
                    //show alert
//                    UIAlertController.actionWith(Bundle.main.getAppName(), andMessage: popUpMessage.emailNotFound.rawValue, getStyle: .alert, controller: self, buttons: ["Ok"]) { (_) in }
                }
            }
        }
    }
    }

